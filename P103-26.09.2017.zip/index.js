$(document).ready(function(){

	$('.show').click(function () {
		$('.box').show()				 
				 .fadeOut(1000);

	});


	$('.hide').click(function () {
		$('.box').hide();
	});

	$('.fadeIn').click(function () {
		$('.box').fadeIn(2000);
	});

	$('.fadeOut').click(function () {
		$('.box').fadeOut(2000);
	});

	$('.fadeToggle').click(function () {
		$('.box').fadeToggle(2000);
	});

	$('.slideDown').click(function () {
		$('.box').slideDown(5000);
	});

	$('.slideUp').click(function () {
		$('.box').slideUp(2000);
	});

	$('.slideToggle').click(function () {
		$('.box').slideToggle(2000);
	});

	// $('.onElement').on('click',function () {
	// 	alert(1)
	// });
	// var a=9;
	// $('.onElement').on({
	// 	click:function () {
	// 		console.log('click '+a);

	// 	},
	// 	mouseover:function () {
	// 		console.log('mouseover')
	// 	}
	// });


		//left:'+=50px'

		var i=0;
	$('.animate').click(function(){
		i++;
		var leftx=i*200;


		$('#myDiv').animate({
			left:(leftx)+'px'
		},2000);

		console.log($('#myDiv').width())
		console.log($('body').width())
	});



		
});