# P103-21.09.2017

1. Verilen melumatlardan slider hazirlamaq.Sag ve soldaki buttonlara klik edende verilen array-in elementlerini ekranda gosdersin
Numune:
https://drive.google.com/a/code.edu.az/file/d/0BwFK86MfCyASdkJQcm1Dd3V1WnM/view?usp=sharing
  
  Verilen melumatlar asagidaki formatda olsun:
  <pre>
  var sliderItems=[
	{
		imgSrc:'https://www.metaslider.com/wp-content/uploads/2014/11/mountains1.jpg',
		title:'Slider 1'
	},
	{
		imgSrc:'https://www.metaslider.com/wp-content/uploads/2014/11/mountains1.jpg',
		title:'Slider 2'
	}
];
</pre>
