$(document).ready(function(){
	//$('.myDiv').append('<div class="test">hello</div>')
	$('.myDiv').prepend('<div class="test">hello</div>');
	$('.list').prepend('<li>Item 2</li>');

	//$('.myDiv').find('p').css('color','red');

	//$('p').remove('.p2');

	//$('.myElement').parent().parent().css('padding','5px');
	//$('.myElement').parents('.myDiv').css('padding','5px')
	//$('.myElement').parentsUntil('body').css('padding','5px')
	$('.myElement').parents('body')
				   .find('.myDiv>p')
				   .css('color','red');


	$('.acc-title').click(function () {
		console.log($(this).hasClass('acc-title 2'))
	console.log($(this).attr('class'))

		$(this).parents('.accordionItem')
			   .find('.acc-content')
			   .slideToggle();
	});

	// $('.list').next('div')
	// 		  .css('color','red');

	// $('.aaDiv').prevAll().css('color','purple');


	$('.list2 li').eq(0).css('color','purple');

	var count=$('.list2 li').length/2;

	$('.list2 li').eq(count)
				.addClass('breakpoint')
				;


	// $('.list2 li.breakpoint').prevAll()
	// 						.css('color','green');

	// $('.list2 li.breakpoint').prev()
	// 						 .nextAll()
	// 						 .css('color','red');


	$('.list2 li').css('color','red');
	$('.list2 li.breakpoint').prevAll()
	 						.css('color','green');



	//$('.list2 li').first().css('color','green');

	//$('.list2 li').last().css('color','purple');



	// console.log($('.divPosition').offset());
	console.log($('.divChild').offset());
	//console.log($('.divChild').position());


	$(window).scroll(function () {
		
		var divOffsetTop=$('.divChild').offset().top;

		if ($(window).scrollTop()>divOffsetTop) {
			$('.divChild').addClass('effect1')
		}
	});

	$('.menu-item').click(function () {
		var dataLink=$(this).attr('data-link');
		var divOffsetTop=$('#'+dataLink).offset().top;
		console.log(divOffsetTop)
		$('html').animate({
			scrollTop:divOffsetTop+'px'
		},2000);
	});
});