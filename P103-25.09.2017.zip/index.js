

var helloElement=document.querySelector('#hello');
var worldElement=document.querySelector('#world');


helloElement.nextSibling.style.color='red';
//helloElement.nextElementSibling.style.color='red';





// setTimeout(function(){
// 	alert('hello');
// },500);


/*********************************/

// var timeElement=document.querySelector("#time");


// var arr='salam';

// var i=0;


// var arrInterval= setInterval(function () {
// 	if (i<arr.length) {
// 		timeElement.innerHTML+=arr[i]+'<br>';
// 		i++;
// 	}else{
// 		clearInterval(arrInterval);
// 	}
// 	console.log('step');
// },1000);


// var a = new Date();



// console.log(a);
// console.log(a.getMonth());
// console.log(a.getDay());
// console.log(a.getDate());
// console.log(a.getYear());
// console.log(a.getFullYear());

// console.log(Date.now());

// var b = new Date(2001,24,01);
// console.log(b);


// var c=3000;
// console.log(c);

// var d=new Date(c);
// console.log(d);









