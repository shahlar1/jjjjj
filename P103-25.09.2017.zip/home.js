var start=Date.now();

var title=document.getElementsByClassName("title");
var title=document.querySelectorAll(".title");

console.log(title)
var pclass=document.querySelectorAll(".pclass");
 title[0].addEventListener('click',function() {
 	 pclass[0].style.display="block";
 	 pclass[1].style.display="none";
 	 pclass[2].style.display="none";

 	 })


  title[1].addEventListener('click',function() {
 	 pclass[0].style.display="none";
 	 pclass[1].style.display="block";
 	 pclass[2].style.display="none";

 	 })

  title[2].addEventListener('click',function() {
 	 pclass[0].style.display="none";
 	 pclass[1].style.display="none";
 	 pclass[2].style.display="block";

 	 })

var end =Date.now();

var a=end-start;


console.log(a)