$(document).ready(function(){
	$('.modal-image img').click(function () {
	
		var imgSrc=$(this).attr('src');

		$('.modal-content-img').attr('src',imgSrc);
		
		$('.modal').show();

		var imgwidth=$('.modal-content-img').css('width')

		$('.modal-content').css({
			'width':imgwidth
		});

	});

	$('.close').click(function () {
		$('.modal').hide();
	});


	//console.log($('.myDiv').html())

	// $('.modal-image img').each(function () {
	// 	console.log($(this).attr('src'));
	// });

	$('.modal-image').each(function () {
		console.log($(this).find('img').attr('src'));
		console.log($(this).find('p').text());
	});


	$('.myDiv').find('.div-title').css('color','red');


});