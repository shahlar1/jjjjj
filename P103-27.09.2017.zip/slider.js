$(document).ready(function () {
	
	var sliderItemCount=$('.slider li').length;
	var sliderItemWidth=$('.slider li img').width();
	
	var sliderWidth=sliderItemCount*sliderItemWidth;

	$('.slider').css({
		'width':sliderWidth+'px'
	});

	var i=0;
	$('.next').click(function () {	
		/*console.log($('.slider').css('margin-left'))
		i++;
		var widthx=i*sliderItemWidth;

		$('.slider').animate({
			'margin-left':'-'+widthx+'px'
		},2000);*/
		console.log($('.slider').css('margin-left'))
		i--;
		var marginLeft=i*sliderItemWidth;
		// console.log(Math.abs(marginLeft));
		if (i<=sliderItemCount-1){

			$('.slider').animate({
			'margin-left':marginLeft+'px'
		},500);
		}
		else{
			
		}
		

	})

});

