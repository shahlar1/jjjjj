$(document).ready(function(){

	console.log($('.box').html());

	//$('.box').text('<p>salam</p>');
	$('.box').html('<p>salam</p>');

	$('#myInput').val('hello 23');

	var inputVal=$('#myInput').val();

	console.log(inputVal);



	$('#btnAdd').click(function () {
		$('.box').addClass('class15');
		$('#myInput').removeClass('input-class');

		//$('.box').css('color','white');

		$('.box').css({
			'color':'white',
			'font-size':'20px',
			'margin':'20px',
			'padding':'5px'
		});

		console.log($('.box').attr('class'));

		$('.box').attr('data-attribute','hello world');
		$('.box').attr('id','seid');





	});


		var a=9;
		var b=3;

		$('.calculate').click(function () {
			var command=$(this).attr('data-command');

			var netice=0;
			switch(command){
				case 'plus':
					netice=a+b;
				break;

				case 'minus':
					netice=a-b;
				break;

				default:
					netice=-1;
				break;
			}

			console.log(netice);

		});



});